import pandas as pd
from pulp import LpProblem, LpVariable, LpMinimize, lpSum, LpStatus

# 평가 함수 정의
def evaluate_model(results, original_data, avg_interval, min_interval, max_interval):
    """
    최적화 결과를 평가하는 함수.
    """
    evaluation = {}

    # 1. 평균 배차 간격 편차
    actual_avg_interval = results["배차 간격"].mean()
    evaluation["avg_interval_deviation"] = abs(actual_avg_interval - avg_interval)

    # 2. 최소/최대 배차 간격 위반
    evaluation["min_interval_violations"] = (results["배차 간격"] < min_interval).sum()
    evaluation["max_interval_violations"] = (results["배차 간격"] > max_interval).sum()

    # 3. 혼잡도 분석
    congestion_analysis = {}
    if "혼잡도" in original_data.columns:
        merged_data = pd.merge(
            results, original_data, left_on=["출발역", "시간대", "방향"], right_on=["출발역", "시간", "상하구분"]
        )
        congestion_analysis["optimized_avg_congestion"] = merged_data["혼잡도"].mean()
        congestion_analysis["original_avg_congestion"] = original_data["혼잡도"].mean()
        congestion_analysis["congestion_reduction"] = congestion_analysis["original_avg_congestion"] - congestion_analysis["optimized_avg_congestion"]
    else:
        congestion_analysis["optimized_avg_congestion"] = float("nan")
        congestion_analysis["original_avg_congestion"] = original_data["혼잡도"].mean()
        congestion_analysis["congestion_reduction"] = float("nan")
    
    evaluation["congestion_analysis"] = congestion_analysis
    return evaluation

# 최적화 및 평가 실행
def run_optimization_and_evaluation(data, avg_interval, min_interval, max_interval, day_type):
    """
    최적화 실행 및 평가
    """
    def optimize_schedule(data):
        time_slots = data['시간'].unique()
        stations = data['출발역'].unique()
        directions = data['상하구분'].unique()
        model = LpProblem(name="혼잡도_최소화_배차간격_최적화", sense=LpMinimize)

        # 변수 정의
        decision_vars = {
            (station, time, direction): LpVariable(
                f"t_{station}_{time}_{direction}", lowBound=min_interval, upBound=max_interval
            )
            for station in stations for time in time_slots for direction in directions
        }

        # 혼잡도 가중치 적용
        congestion_values = {
            (row['출발역'], row['시간'], row['상하구분']): row['혼잡도']
            for _, row in data.iterrows()
        }

        # 동적 가중치 적용: 혼잡도가 높을수록 더 큰 가중치
        beta_dynamic = {key: 2 if congestion_values[key] > 0.7 else 1 for key in decision_vars}

        # 목적 함수: 혼잡도 최소화
        model += lpSum(
            beta_dynamic[(station, time, direction)] * congestion_values[(station, time, direction)] * decision_vars[(station, time, direction)]
            for station, time, direction in decision_vars
        ), "혼잡도_최소화"

        # 제약 조건: 평균 배차 간격 유지
        for station in stations:
            for direction in directions:
                model += (
                    lpSum(decision_vars[(station, time, direction)] for time in time_slots) / len(time_slots)
                    == avg_interval, f"평균배차_{station}_{direction}"
                )

        model.solve()
        if model.status == 1:
            results = []
            for station, time, direction in decision_vars:
                results.append({
                    "출발역": station, "시간대": time, "방향": direction, "배차 간격": decision_vars[(station, time, direction)].varValue
                })
            return pd.DataFrame(results)
        else:
            print(f"{day_type} 최적화 실패")
            return None

    # 최적화 및 평가 실행
    results = optimize_schedule(data)
    if results is not None:
        evaluation = evaluate_model(results, data, avg_interval, min_interval, max_interval)
        print(f"\n{day_type} 평가 결과:")
        print(evaluation)
        return results, evaluation
    else:
        print(f"{day_type} 데이터 평가 불가능")
        return None, None

# 데이터 로드
data = pd.read_csv('평일_주말_혼잡도_평균.csv', encoding='utf-8')
weekday_data = data[data['요일구분'] == '평일']
weekend_data = data[data['요일구분'] == '주말']

# 평일 및 주말 실행
weekday_results, weekday_evaluation = run_optimization_and_evaluation(weekday_data, avg_interval=4.5, min_interval=4, max_interval=5, day_type="평일")
weekend_results, weekend_evaluation = run_optimization_and_evaluation(weekend_data, avg_interval=9, min_interval=8, max_interval=10, day_type="주말")

# 평가 결과 엑셀로 저장
if weekday_evaluation or weekend_evaluation:
    results_to_save = []
    
    # 평일 평가 결과
    if weekday_evaluation:
        results_to_save.append({
            "구분": "평일",
            "평균 배차 간격 편차": weekday_evaluation["avg_interval_deviation"],
            "최소 배차 간격 위반 횟수": weekday_evaluation["min_interval_violations"],
            "최대 배차 간격 위반 횟수": weekday_evaluation["max_interval_violations"],
            "최적화된 평균 혼잡도": weekday_evaluation["congestion_analysis"]["optimized_avg_congestion"],
            "원본 평균 혼잡도": weekday_evaluation["congestion_analysis"]["original_avg_congestion"],
            "혼잡도 감소량": weekday_evaluation["congestion_analysis"]["congestion_reduction"]
        })

    # 주말 평가 결과
    if weekend_evaluation:
        results_to_save.append({
            "구분": "주말",
            "평균 배차 간격 편차": weekend_evaluation["avg_interval_deviation"],
            "최소 배차 간격 위반 횟수": weekend_evaluation["min_interval_violations"],
            "최대 배차 간격 위반 횟수": weekend_evaluation["max_interval_violations"],
            "최적화된 평균 혼잡도": weekend_evaluation["congestion_analysis"]["optimized_avg_congestion"],
            "원본 평균 혼잡도": weekend_evaluation["congestion_analysis"]["original_avg_congestion"],
            "혼잡도 감소량": weekend_evaluation["congestion_analysis"]["congestion_reduction"]
        })

    # 데이터프레임 생성 및 엑셀 저장
    eval_df = pd.DataFrame(results_to_save)
    excel_path = "혼잡도_최적화_결과.xlsx"
    eval_df.to_excel(excel_path, index=False, sheet_name="평가 결과")

    print(f"\n평가 결과가 '{excel_path}' 파일에 저장되었습니다.")
